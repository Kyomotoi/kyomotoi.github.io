---
title: ;w;
---
恭喜你找到了一只黄焖鸡，兼酸菜鱼和臭鱼烂虾

## 联系我
- Github: [Kyomotoi](https://github.com/Kyomotoi)
- Email: kyomotoiowo@gmail.com
- Telegram: [Kyomotoi owo](https://t.me/kyomotoi)